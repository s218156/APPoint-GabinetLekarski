class Office{
  late int id;
  late String officeNum;
  Office(this.id,this.officeNum);
}