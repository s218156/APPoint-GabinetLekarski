class Doctor{
  late int id;
  late String name;
  late String surname;
  late String specialization;
  Doctor(this.id, this.name, this.surname, this.specialization);
}