package com.appoint.appoint_webapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
