class User{
  late String username;
  late String token;
  late DateTime dateOfRegister;
  late String refreshToken;

}